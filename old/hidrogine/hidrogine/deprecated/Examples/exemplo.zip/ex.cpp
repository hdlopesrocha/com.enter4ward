#include <iostream>
#include <string>
#include <cstdlib>
#include <fstream>

using namespace std;

int main(){


	ifstream input("pasta/ficheiro");
	if (input.is_open())
	{
		string line;
		while(!input.eof()){
			line.clear();
			getline(input,line);
			cout << line << endl;
   		}
    	input.close();
    }

	return 0;
}